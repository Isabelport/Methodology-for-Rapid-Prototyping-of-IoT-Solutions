/***** Wi-Fi Credentials *****/
//#define STA_SSID "iPhone Isabel"
//#define STA_PASS "hotspotisabel"
//#define STA_SSID "eot.pt"
//#define STA_PASS "eot_2016"
#define STA_SSID "NOS-9D70"
#define STA_PASS "82cdeb96f5db"
//#define STA_SSID "MobileRouter-0090"
//#define STA_PASS "11639121"
//#define STA_SSID "MEO-CascaSilva"
//#define STA_PASS "afokiko2000"


/***** The ThingsBoard parameters *****/

// if cloud/professional edition 
#define THINGSBOARD_SERVER  "iot.istartlab.tecnico.ulisboa.pt"

//ESP32 Token
#define TOKEN "Xsh1AGQsAperP4vb0Q7M" //esp1